﻿#include "Render.h"
#include <Windows.h>
#include <GL\GL.h>
#include <GL\GLU.h>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <random>
#include "GUItextRectangle.h"
#include <cmath>

GLuint texId;


#ifdef _DEBUG
#include <Debugapi.h> 
struct debug_print
{
	template<class C>
	debug_print& operator<<(const C& a)
	{
		OutputDebugStringA((std::stringstream() << a).str().c_str());
		return *this;
	}
} debout;
#else
struct debug_print
{
	template<class C>
	debug_print& operator<<(const C& a)
	{
		return *this;
	}
} debout;
#endif

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


#include "MyOGL.h"
extern OpenGL gl;
#include "Light.h"
Light light;
#include "Camera.h"
Camera camera;


bool texturing = true;
bool lightning = true;
bool alpha = false;


void switchModes(OpenGL* sender, KeyEventArg arg)
{

	auto key = LOWORD(MapVirtualKeyA(arg.key, MAPVK_VK_TO_CHAR));

	switch (key)
	{
	case 'L':
		lightning = !lightning;
		break;
	case 'T':
		texturing = !texturing;
		break;
	case 'A':
		alpha = !alpha;
		break;
	}
}


GuiTextRectangle text;


void initRender()
{
	//==============НАСТРОЙКА ТЕКСТУР================

	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

	glGenTextures(1, &texId);

	glBindTexture(GL_TEXTURE_2D, texId);


	int x, y, n;

	unsigned char* data = stbi_load("texture.png", &x, &y, &n, 4);
	
	unsigned char* _tmp = new unsigned char[x * 4]; 
	for (int i = 0; i < y / 2; ++i)
	{
		std::memcpy(_tmp, data + i * x * 4, x * 4);
		std::memcpy(data + i * x * 4, data + (y - 1 - i) * x * 4, x * 4); 
		std::memcpy(data + (y - 1 - i) * x * 4, _tmp, x * 4); 
	}
	delete[] _tmp;


	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, x, y, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);

	
	stbi_image_free(data);


	
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	//======================================================

	//================НАСТРОЙКА КАМЕРЫ======================
	camera.caclulateCameraPos();

	
	gl.WheelEvent.reaction(&camera, &Camera::Zoom);
	gl.MouseMovieEvent.reaction(&camera, &Camera::MouseMovie);
	gl.MouseLeaveEvent.reaction(&camera, &Camera::MouseLeave);
	gl.MouseLdownEvent.reaction(&camera, &Camera::MouseStartDrag);
	gl.MouseLupEvent.reaction(&camera, &Camera::MouseStopDrag);
	//==============НАСТРОЙКА СВЕТА===========================
	
	gl.MouseMovieEvent.reaction(&light, &Light::MoveLight);
	gl.KeyDownEvent.reaction(&light, &Light::StartDrug);
	gl.KeyUpEvent.reaction(&light, &Light::StopDrug);
	//========================================================
	//====================Прочее==============================
	gl.KeyDownEvent.reaction(switchModes);
	text.setSize(512, 180);
	//========================================================


	camera.setPosition(2, 1.5, 1.5);
}
void Bottom(int seed = 0)
{
	extern GLuint texId;
	extern bool   texturing, alpha;

	std::mt19937 gen(seed);
	std::uniform_real_distribution<double> rnd(0.0, 1.0);

	// Новые координаты точек
	double A[]{ 0.5, 0.5, 0 };
	double A1[]{ 0.5, 0.5, 1 };

	double B[]{ 0, 2.5, 0 };
	double B1[]{ 0, 2.5, 1 };

	double C[]{ -0.5, 0.5, 0 };
	double C1[]{ -0.5, 0.5, 1 };

	double D[]{ -2.5, 0, 0 };
	double D1[]{ -2.5, 0, 1 };

	double E[]{ -3, -2.5, 0 };
	double E1[]{ -3, -2.5, 1 };

	double F[]{ 0, -1, 0 };
	double F1[]{ 0, -1, 1 };

	double G[]{ 4.5, 0, 0 };
	double G1[]{ 4.5, 0, 1 };

	double H[]{ 2, -2.5, 0 };
	double H1[]{ 2, -2.5, 1 };

	// Функция для расчета нормали
	auto setN = [](const double* p0, const double* p1, const double* p2, const double* ref) {
		double u[3] = { p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2] };
		double v[3] = { p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2] };

		double nx = u[1] * v[2] - u[2] * v[1];
		double ny = u[2] * v[0] - u[0] * v[2];
		double nz = u[0] * v[1] - u[1] * v[0];

		double len = sqrt(nx * nx + ny * ny + nz * nz);
		if (len > 0.00001) {
			nx /= len;
			ny /= len;
			nz /= len;
		}

		// Проверка направления
		double dx = ref[0] - p0[0];
		double dy = ref[1] - p0[1];
		double dz = ref[2] - p0[2];

		if (nx * dx + ny * dy + nz * dz > 0) {
			nx = -nx;
			ny = -ny;
			nz = -nz;
		}

		glNormal3d(nx, ny, nz);
		};

	// Центральная точка для расчета нормалей
	double center[3] = { 0, 0, 0.5 };

	if (alpha) {
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glDepthMask(GL_FALSE);
	}

	if (texturing) {
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, texId);
	}

	// 1. Нижняя поверхность (дно)
	glBegin(GL_QUADS);
	glColor3d(0.9, 0.3, 1);  // Фиолетовый цвет
	glNormal3d(0, 0, -1);     // Нормаль вниз

	// Первый четырехугольник
	if (texturing) glTexCoord2d(0.0, 0.0); glVertex3dv(A);
	if (texturing) glTexCoord2d(0.5, 0.0); glVertex3dv(B);
	if (texturing) glTexCoord2d(0.5, 0.5); glVertex3dv(C);
	if (texturing) glTexCoord2d(0.0, 0.5); glVertex3dv(F);

	// Второй четырехугольник
	if (texturing) glTexCoord2d(0.0, 0.0); glVertex3dv(A);
	if (texturing) glTexCoord2d(1.0, 0.0); glVertex3dv(G);
	if (texturing) glTexCoord2d(1.0, 0.5); glVertex3dv(H);
	if (texturing) glTexCoord2d(0.0, 0.5); glVertex3dv(F);

	// Третий четырехугольник
	if (texturing) glTexCoord2d(0.5, 0.5); glVertex3dv(C);
	if (texturing) glTexCoord2d(0.0, 0.5); glVertex3dv(D);
	if (texturing) glTexCoord2d(0.0, 1.0); glVertex3dv(E);
	if (texturing) glTexCoord2d(0.5, 1.0); glVertex3dv(F);
	glEnd();

	// 2. Боковые поверхности
	glBegin(GL_QUADS);
	auto drawSide = [&](double* p1, double* p2, double* p3, double* p4) {
		glColor3d(rnd(gen), rnd(gen), rnd(gen));
		setN(p1, p2, p3, center);

		if (texturing) glTexCoord2d(0.0, 0.0); glVertex3dv(p1);
		if (texturing) glTexCoord2d(1.0, 0.0); glVertex3dv(p2);
		if (texturing) glTexCoord2d(1.0, 1.0); glVertex3dv(p3);
		if (texturing) glTexCoord2d(0.0, 1.0); glVertex3dv(p4);
		};

	// Рисуем все боковые грани
	drawSide(E, E1, D1, D);   // Грань E-D
	drawSide(D, D1, C1, C);   // Грань D-C
	drawSide(C, C1, B1, B);   // Грань C-B
	drawSide(B, B1, A1, A);   // Грань B-A
	drawSide(A, A1, G1, G);   // Грань A-G
	drawSide(G, G1, H1, H);   // Грань G-H
	drawSide(H, H1, F1, F);   // Грань H-F
	drawSide(F, F1, E1, E);   // Грань F-E
	glEnd();

	// 3. Верхняя поверхность (крышка)
	glColor4d(1, 0, 1, alpha ? 0.55 : 1.0);  // Фиолетовый с прозрачностью
	glBegin(GL_QUADS);
	glNormal3d(0, 0, 1);  // Нормаль вверх

	// Первый четырехугольник
	if (texturing) glTexCoord2d(0.0, 0.0); glVertex3dv(A1);
	if (texturing) glTexCoord2d(0.5, 0.0); glVertex3dv(B1);
	if (texturing) glTexCoord2d(0.5, 0.5); glVertex3dv(C1);
	if (texturing) glTexCoord2d(0.0, 0.5); glVertex3dv(F1);

	// Второй четырехугольник
	if (texturing) glTexCoord2d(0.0, 0.0); glVertex3dv(A1);
	if (texturing) glTexCoord2d(1.0, 0.0); glVertex3dv(G1);
	if (texturing) glTexCoord2d(1.0, 0.5); glVertex3dv(H1);
	if (texturing) glTexCoord2d(0.0, 0.5); glVertex3dv(F1);

	// Третий четырехугольник
	if (texturing) glTexCoord2d(0.5, 0.5); glVertex3dv(C1);
	if (texturing) glTexCoord2d(0.0, 0.5); glVertex3dv(D1);
	if (texturing) glTexCoord2d(0.0, 1.0); glVertex3dv(E1);
	if (texturing) glTexCoord2d(0.5, 1.0); glVertex3dv(F1);
	glEnd();

	// Отключаем специальные режимы
	if (texturing) {
		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}

	if (alpha) {
		glDepthMask(GL_TRUE);
		glDisable(GL_BLEND);
	}
}

void Render(double delta_time)
{
	glEnable(GL_DEPTH_TEST);

	if (gl.isKeyPressed('F')) 
	{
		light.SetPosition(camera.x(), camera.y(), camera.z());
	}
	camera.SetUpCamera();
	light.SetUpLight();


	
	gl.DrawAxes();

	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);


	
	if (lightning)
		glEnable(GL_LIGHTING);
	if (texturing)
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, 0);
	}

	if (alpha)
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	}

	//=============НАСТРОЙКА МАТЕРИАЛА==============


	
	float  amb[] = { 0.2, 0.2, 0.1, 1. };
	float dif[] = { 0.4, 0.65, 0.5, 1. };
	float spec[] = { 0.9, 0.8, 0.3, 1. };
	float sh = 0.2f * 256;

	
	glMaterialfv(GL_FRONT, GL_AMBIENT, amb);

	glMaterialfv(GL_FRONT, GL_DIFFUSE, dif);
	
	glMaterialfv(GL_FRONT, GL_SPECULAR, spec);
	
	glMaterialf(GL_FRONT, GL_SHININESS, sh);

	
	glShadeModel(GL_SMOOTH);
	

//============ РИСОВАТЬ ТУТ ==============


	Bottom();





	//===============================================

	light.DrawLightGizmo();

	//================Сообщение в верхнем левом углу=======================

	
	glMatrixMode(GL_PROJECTION);
	
	glPushMatrix();
	
	glLoadIdentity();

	glOrtho(0, gl.getWidth() - 1, 0, gl.getHeight() - 1, 0, 1);

	
	glMatrixMode(GL_MODELVIEW);
	
	glPushMatrix();
	
	glLoadIdentity();



	std::wstringstream ss;
	ss << std::fixed << std::setprecision(3);
	ss << "T - " << (texturing ? L"[вкл]выкл  " : L" вкл[выкл] ") << L"текстур" << std::endl;
	ss << "L - " << (lightning ? L"[вкл]выкл  " : L" вкл[выкл] ") << L"освещение" << std::endl;
	ss << "A - " << (alpha ? L"[вкл]выкл  " : L" вкл[выкл] ") << L"альфа-наложение" << std::endl;
	ss << L"F - Свет из камеры" << std::endl;
	ss << L"G - двигать свет по горизонтали" << std::endl;
	ss << L"G+ЛКМ двигать свет по вертекали" << std::endl;
	ss << L"Коорд. света: (" << std::setw(7) << light.x() << "," << std::setw(7) << light.y() << "," << std::setw(7) << light.z() << ")" << std::endl;
	ss << L"Коорд. камеры: (" << std::setw(7) << camera.x() << "," << std::setw(7) << camera.y() << "," << std::setw(7) << camera.z() << ")" << std::endl;
	ss << L"Параметры камеры: R=" << std::setw(7) << camera.distance() << ",fi1=" << std::setw(7) << camera.fi1() << ",fi2=" << std::setw(7) << camera.fi2() << std::endl;
	ss << L"delta_time: " << std::setprecision(5) << delta_time << std::endl;


	text.setPosition(10, gl.getHeight() - 10 - 180);
	text.setText(ss.str().c_str());
	text.Draw();

	
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();


}